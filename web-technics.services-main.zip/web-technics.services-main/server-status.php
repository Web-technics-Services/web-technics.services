<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Server Status | Web Technics</title>
  <meta name="description" content="Internal infrastructure dashboard for Web Technics showing uptime, load, performance metrics, technology stack, and security posture.">
  <meta name="robots" content="noindex, follow">
  <link rel="canonical" href="https://web-technics.services/server-status.php">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Sora:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <link rel="icon" type="image/svg+xml" href="assets/branding/web-technics-icon-favicon.svg">
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <a class="brand" href="index.html" aria-label="Web Technics home">
        <img class="brand-logo" src="assets/branding/web-technics-logo-horizontal.svg" alt="Web Technics logo">
      </a>
      <button class="menu-toggle" aria-expanded="false" aria-label="Open menu">Menu</button>
      <nav class="nav-links" aria-label="Primary">
        <a href="services.html">Services</a>
        <a href="portfolio.html">Portfolio</a>
        <a class="active" href="server-status.html">Server Status</a>
        <a href="contact.html">Contact</a>
        <a href="about.html">About</a>
      </nav>
    </div>
  </header>

  <main>
    <section class="page-hero">
      <div class="container reveal">
        <span class="eyebrow">Infrastructure Dashboard</span>
        <h1 style="margin-top:16px;">Server Status</h1>
        <p>Real-time infrastructure metrics showcasing our robust VPS performance, reliability, and security posture.</p>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="status-hero">
          <article class="card reveal status-panel">
            <div class="status-banner">
              <p class="kicker">Overall Status</p>
              <h2 style="font-size:clamp(1.8rem, 3vw, 2.4rem); margin-top:10px;">All Systems Operational</h2>
              <p style="margin-top:12px; color: var(--muted);">No active incidents are currently reported. Monitoring is continuous and alerts are handled as priority.</p>
              <div class="status-badges">
                <span class="status-badge"><span class="status-dot"></span>Operational</span>
                <span class="status-badge">24/7 Monitoring</span>
                <span class="status-badge">Automatic Alerts</span>
                <span class="status-badge">Last updated: <span id="status-time">just now</span></span>
              </div>
            </div>
            <div class="status-note">
              <div><strong>What this means:</strong> our internal hosting stack is healthy, searchable, and ready to support live client projects with minimal latency.</div>
              <div><strong>Operational focus:</strong> uptime, delivery speed, resilience, and recovery discipline.</div>
            </div>
          </article>

          <article class="card reveal">
            <p class="kicker">Core Metrics</p>
            <div class="status-grid" style="margin-top:12px;">
              <div class="status-card">
                <p class="status-value">2 weeks</p>
                <p class="status-subtext">Uptime window</p>
              </div>
              <div class="status-card">
                <p class="status-value">0.4%</p>
                <p class="status-subtext">CPU load</p>
              </div>
              <div class="status-card">
                <p class="status-value">16.7%</p>
                <p class="status-subtext">Memory in use</p>
              </div>
            </div>
            <ul class="list-clean" style="margin-top:18px;">
              <li>Up 2 weeks, 1 day, 23 hours, 43 minutes</li>
              <li>Load: 0.01, 0.05, 0.07</li>
              <li>1324 MB / 7936 MB used</li>
            </ul>
          </article>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container reveal">
        <div class="section-head">
          <h2>Performance Metrics</h2>
          <p>These measurements show the server is optimized for responsiveness and stable application delivery.</p>
        </div>
        <div class="status-grid">
          <article class="status-card">
            <p class="kicker">Server Response Time (TTFB)</p>
            <p class="status-value">5.08ms</p>
            <p class="status-subtext">Excellent target result, well below 200ms.</p>
          </article>
          <article class="status-card">
            <p class="kicker">PHP Version</p>
            <p class="status-value">8.3.12</p>
            <p class="status-subtext">Latest stable release</p>
          </article>
          <article class="status-card">
            <p class="kicker">HTTP Protocol</p>
            <p class="status-value">HTTP/2</p>
            <p class="status-subtext">Optimized for speed</p>
          </article>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container reveal">
        <div class="section-head">
          <h2>Technology Stack</h2>
          <p>The infrastructure is built on a modern, efficient stack designed for stable delivery and maintainability.</p>
        </div>
        <div class="stack-grid">
          <article class="stack-item"><p class="stack-title">PHP</p><p class="stack-value">8.3.12</p></article>
          <article class="stack-item"><p class="stack-title">MySQL</p><p class="stack-value">8.0+</p></article>
          <article class="stack-item"><p class="stack-title">Nginx</p><p class="stack-value">Web Server</p></article>
          <article class="stack-item"><p class="stack-title">Linux</p><p class="stack-value">Ubuntu/Debian</p></article>
        </div>
        <div class="card" style="margin-top: 14px;">
          <p class="kicker">Server Software</p>
          <p style="margin-top:8px; font-size:1.05rem; font-weight:700; color: var(--text);">nginx/1.21.4</p>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container reveal">
        <div class="section-head">
          <h2>Infrastructure & Security</h2>
          <p>These controls keep the platform secure, recoverable, and ready to handle traffic spikes.</p>
        </div>
        <div class="security-grid">
          <article class="security-card"><div class="security-icon">🔒</div><h3>SSL/TLS Encryption</h3><p>All connections secured with HTTPS and modern encryption protocols.</p></article>
          <article class="security-card"><div class="security-icon">🛡️</div><h3>CDN Integration</h3><p>Cloudflare CDN for global content delivery and DDoS protection.</p></article>
          <article class="security-card"><div class="security-icon">💾</div><h3>Automated Backups</h3><p>Daily backups with 30-day retention and point-in-time recovery.</p></article>
          <article class="security-card"><div class="security-icon">⚡</div><h3>Server-Side Caching</h3><p>Redis and OPcache for optimized application performance.</p></article>
          <article class="security-card"><div class="security-icon">📡</div><h3>24/7 Monitoring</h3><p>Real-time server monitoring with instant alerts and notifications.</p></article>
          <article class="security-card"><div class="security-icon">⚖️</div><h3>Load Balancing</h3><p>Distributed architecture ready to handle traffic spikes.</p></article>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container reveal">
        <div class="cta-band">
          <p class="kicker">Impressed by Our Infrastructure?</p>
          <h2>Let us build a fast, secure, and scalable web solution for your business.</h2>
          <p style="margin-top:12px; color:#d4eaed; max-width:700px;">These performance and security foundations are the same principles we use when delivering client websites, web apps, and SEO-focused platforms.</p>
          <div class="actions">
            <a class="btn btn-primary" href="contact.html">Get Started</a>
            <a class="btn btn-secondary" href="portfolio.html">View Projects</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-grid">
      <div class="footer-col">
        <h3>Quick Links</h3>
        <a href="about.html">About</a>
        <a href="portfolio.html">Portfolio</a>
        <a href="services.html">Services</a>
        <a href="contact.html">Contact</a>
      </div>
      <div class="footer-col">
        <h3>Usefull Links</h3>
        <a href="server-status.html">Server Status</a>
      </div>
      <div class="footer-col">
        <h3>Network Links</h3>
        <a href="#">Coming soon</a>
      </div>
      <div class="footer-col">
        <h3>Connect</h3>
        <a href="https://github.com/web-technics" target="_blank" rel="noreferrer">GitHub</a>
        <a href="mailto:info@web-technics.services">info@web-technics.services</a>
        <a href="tel:+855969245074">+855 96 924 5074</a>
        <a href="https://wa.me/855965345954" target="_blank" rel="noreferrer">WhatsApp</a>
        <a href="https://t.me/web_technics_services" target="_blank" rel="noreferrer">Telegram</a>
      </div>
    </div>
    <div class="container footer-bottom">
      <p class="footer-signature"><img class="footer-logo" src="assets/branding/web-technics-icon-favicon.svg" alt="Web Technics icon">@<span data-year></span> Web-technics services.</p>
      <p>Server Status</p>
    </div>
  </footer>

  <script>
    const statusTime = document.getElementById("status-time");
    if (statusTime) {
      statusTime.textContent = new Date().toLocaleString();
    }
  </script>
  <script src="app.js"></script>
</body>
</html>
